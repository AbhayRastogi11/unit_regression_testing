import requests
import json
import os
from typing import Optional
from dotenv import load_dotenv
load_dotenv()
def get_microsoft_access_token(
    client_id: str,
    client_secret: str,
    tenant_id: str = os.environ.get("TENANT_ID", "common"),
    grant_type: str = "client_credentials",
    scope: str = "https://graph.microsoft.com/.default"
) -> Optional[str]:
    """
    Get Microsoft Graph API access token using OAuth2 client credentials flow.
    
    Args:
        client_id: Azure App Registration Client ID
        client_secret: Azure App Registration Client Secret
        tenant_id: Azure Tenant ID (default provided)
        grant_type: OAuth2 grant type (default: client_credentials)
        scope: API scope (default: Microsoft Graph)
    
    Returns:
        Access token string or None if failed
    """
    
    # OAuth2 token endpoint URL
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    
    # Request headers
    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }
    
    # Request body data
    data = {
        "client_id": client_id,
        "client_secret": client_secret,
        "grant_type": grant_type,
        "scope": scope
    }
    
    try:
        print(f"Requesting access token from: {token_url}")
        
        # Make POST request
        response = requests.post(
            url=token_url,
            headers=headers,
            data=data,
            timeout=30
        )
        
        # Check if request was successful
        response.raise_for_status()
        
        # Parse JSON response
        token_data = response.json()
        
        # Extract access token
        access_token = token_data.get("access_token")
        
        if access_token:
            print("✓ Access token obtained successfully")
            # Print token info (optional)
            token_type = token_data.get("token_type", "Bearer")
            expires_in = token_data.get("expires_in", "Unknown")
            print(f"  Token Type: {token_type}")
            print(f"  Expires In: {expires_in} seconds")
            return access_token
        else:
            print("✗ Access token not found in response")
            print("Response:", json.dumps(token_data, indent=2))
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"✗ Request failed: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response Status: {e.response.status_code}")
            print(f"Response Body: {e.response.text}")
        return None
        
    except json.JSONDecodeError as e:
        print(f"✗ Failed to parse JSON response: {e}")
        return None
        
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        return None

def main():
    """Main function to test the token retrieval"""
    
    # Get credentials from environment variables or set them here
    client_id = os.environ.get("CLIENT_ID", "your_client_id_here")
    client_secret = os.environ.get("CLIENT_SECRET", "your_client_secret_here")
    
    # Optional: different scopes for different APIs
    # For Microsoft Graph API (default)
    scope = "https://graph.microsoft.com/.default"
    
    # For Exchange Online (if needed)
    # scope = "https://outlook.office365.com/.default"
    

    print("=" * 60)
    print("Microsoft OAuth2 Access Token Retrieval")
    print("=" * 60)
    
    access_token = get_microsoft_access_token(
        client_id=client_id,
        client_secret=client_secret,
        scope=scope
    )
    
    if access_token:
        print("\n" + "=" * 60)
        print("ACCESS TOKEN RETRIEVED SUCCESSFULLY")
        print("=" * 60)
        print(f"Token (first 50 chars): {access_token[:50]}...")
        print(f"Full token length: {len(access_token)} characters")
        
        # Optionally save to environment or file
        # os.environ["ACCESS_TOKEN"] = access_token
        
    else:
        print("\n" + "=" * 60)
        print("FAILED TO GET ACCESS TOKEN")
        print("=" * 60)

if __name__ == "__main__":
    main()